package com.flyfile.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlyFileBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
