package com.flyfile.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlyFileBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlyFileBackendApplication.class, args);
	}

}
